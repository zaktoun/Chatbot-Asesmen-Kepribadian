# ============================================================
# Aplikasi Chatbot Psikologi Kepribadian (Final Lokal Version)
# ============================================================

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from datetime import datetime
from docx import Document
import io
from pathlib import Path

# ----------------------------
# KONFIGURASI HALAMAN
# ----------------------------
st.set_page_config(
    page_title="Asesmen Psikologi Kepribadian",
    layout="wide",
    page_icon="🧠"
)

st.title("🧠 Chatbot Asesmen Psikologi Kepribadian")
st.caption("Versi Akademik & Profesional – Disimpan Secara Lokal")

# ----------------------------
# LOGIN / IDENTITAS
# ----------------------------
st.sidebar.header("🪪 Identitas Responden")
nama = st.sidebar.text_input("Nama lengkap")
whatsapp = st.sidebar.text_input("Nomor WhatsApp (opsional)")
usia = st.sidebar.number_input("Usia", min_value=10, max_value=120, step=1)
pekerjaan = st.sidebar.text_input("Pekerjaan / Jabatan")
st.sidebar.markdown("---")

# ----------------------------
# PENGANTAR
# ----------------------------
st.markdown("""
Selamat datang di **Chatbot Psikologi Kepribadian**.  
Silakan isi kuesioner di bawah ini dengan jujur sesuai kondisi diri Anda.  
Gunakan skala 1–5:
> 1 = Sangat Tidak Setuju | 2 = Tidak Setuju | 3 = Netral | 4 = Setuju | 5 = Sangat Setuju
""")

# ----------------------------
# DAFTAR KOMPONEN KEPRIBADIAN
# ----------------------------
domain = {
    "Openness": ["Saya suka mencoba hal baru", "Saya menikmati seni dan imajinasi", "Saya mudah menerima ide-ide baru", "Saya suka belajar hal baru"],
    "Conscientiousness": ["Saya teratur dan disiplin", "Saya menyelesaikan tugas tepat waktu", "Saya membuat rencana sebelum bertindak", "Saya berusaha menjadi teliti"],
    "Extraversion": ["Saya senang bersosialisasi", "Saya aktif berbicara di kelompok", "Saya bersemangat di situasi baru", "Saya suka menjadi pusat perhatian"],
    "Agreeableness": ["Saya mudah bekerja sama", "Saya berempati terhadap orang lain", "Saya berusaha menjaga perasaan orang lain", "Saya suka membantu orang"],
    "Neuroticism": ["Saya mudah merasa cemas", "Saya cepat khawatir terhadap hal kecil", "Saya sulit menenangkan diri", "Saya mudah tersinggung"],
    "Kemandirian": ["Saya yakin dengan keputusan saya sendiri", "Saya tidak mudah terpengaruh tekanan sosial", "Saya mampu bertanggung jawab atas tindakan saya"],
    "Religiusitas": ["Saya menjadikan nilai spiritual sebagai panduan hidup", "Saya menghargai ajaran agama dalam keputusan saya", "Saya berusaha memperbaiki diri secara moral"]
}

# ----------------------------
# INPUT NILAI
# ----------------------------
responses = {}
st.subheader("📝 Kuesioner Kepribadian")

for d, items in domain.items():
    st.markdown(f"### {d}")
    for i, item in enumerate(items):
        key = f"{d}_{i}"
        responses[key] = st.slider(item, 1, 5, 3, key=key)

# ----------------------------
# PROSES ANALISIS
# ----------------------------
if st.button("🔍 Proses Analisis Kepribadian"):
    df = pd.DataFrame(list(responses.items()), columns=["Item", "Skor"])
    df["Domain"] = df["Item"].apply(lambda x: x.split("_")[0])
    result = df.groupby("Domain")["Skor"].mean().reset_index()

    # ----------------------------
    # INFRASTRUKTUR VISUALISASI
    # ----------------------------
    radar = go.Figure()
    radar.add_trace(go.Scatterpolar(
        r=result["Skor"],
        theta=result["Domain"],
        fill="toself",
        name="Profil Kepribadian",
        marker=dict(color='rgba(255,99,132,0.7)')
    ))
    radar.update_layout(
        polar=dict(radialaxis=dict(visible=True, range=[1, 5])),
        showlegend=False,
        height=520
    )
    st.plotly_chart(radar, use_container_width=True)

    donut = go.Figure(data=[go.Pie(
        labels=result["Domain"],
        values=result["Skor"],
        hole=.5
    )])
    donut.update_layout(height=420)
    st.plotly_chart(donut, use_container_width=True)

    # ----------------------------
    # INTERPRETASI
    # ----------------------------
    interpretasi = {}
    for _, row in result.iterrows():
        nilai = row["Skor"]
        if nilai >= 4.2:
            kategori = "Sangat Kuat"
        elif nilai >= 3.5:
            kategori = "Kuat"
        elif nilai >= 2.8:
            kategori = "Sedang"
        elif nilai >= 2.0:
            kategori = "Lemah"
        else:
            kategori = "Sangat Lemah"
        interpretasi[row["Domain"]] = kategori

    st.markdown("### 📊 Interpretasi Kepribadian")
    for d, k in interpretasi.items():
        st.markdown(f"- **{d}** → {k}")

    # ----------------------------
    # PENJELASAN TEKSTUAL
    # ----------------------------
    st.markdown("### 🧩 Analisis Naratif")
    contoh = {
        "Openness": "Kemampuan menerima gagasan baru dan berpikir kreatif.",
        "Conscientiousness": "Kedisiplinan dan tanggung jawab dalam bekerja.",
        "Extraversion": "Kecenderungan bersosialisasi dan tampil percaya diri.",
        "Agreeableness": "Empati, kerjasama, dan kebaikan sosial.",
        "Neuroticism": "Stabilitas emosi dan ketahanan terhadap stres.",
        "Kemandirian": "Kematangan pribadi dalam mengambil keputusan.",
        "Religiusitas": "Kedalaman nilai spiritual dan moral individu."
    }
    for d, k in interpretasi.items():
        st.write(f"**{d} ({k})** — {contoh[d]}")
    # ----------------------------
    # SIMPAN HASIL LOKAL
    # ----------------------------
    resultCp = result.copy()
    resultCp["Nama"] = nama
    resultCp["Usia"] = usia
    resultCp["Pekerjaan"] = pekerjaan
    resultCp["WhatsApp"] = whatsapp
    resultCp["Tanggal"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    csvpath = "hasil_asesmen.csv"
    try:
        p = Path(csvpath)
        if not p.exists():
            resultCp.to_csv(csvpath, index=False)
        else:
            resultCp.to_csv(csvpath, mode='a', header=False, index=False)
    except Exception as e:
        st.error(f"Gagal menyimpan file CSV: {e}")

    # ----------------------------
    # EKSPOR DOCX
    # ----------------------------
    doc = Document()
    doc.add_heading("Laporan Asesmen Kepribadian", level=1)
    doc.add_paragraph(f"Nama: {nama}")
    doc.add_paragraph(f"Usia: {usia}")
    doc.add_paragraph(f"Pekerjaan: {pekerjaan}")
    doc.add_paragraph(f"WhatsApp: {whatsapp}")
    doc.add_paragraph(f"Tanggal: {datetime.now().strftime('%d-%m-%Y %H:%M')}")
    doc.add_paragraph("")

    doc.add_heading("Hasil Skor:", level=2)
    for _, row in result.iterrows():
        doc.add_paragraph(f"{row['Domain']}: {row['Skor']:.2f} ({interpretasi[row['Domain']]})")

    doc.add_heading("Interpretasi:", level=2)
    for d, k in interpretasi.items():
        doc.add_paragraph(f"{d}: {k} – {contoh[d]}")

    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    st.download_button(
        label="💾 Unduh Laporan DOCX",
        data=buffer,
        file_name=f"Laporan_Kepribadian_{nama or 'responden'}.docx",
        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )

    st.success("✅ Analisis selesai! Hasil disimpan lokal & siap diunduh.")
