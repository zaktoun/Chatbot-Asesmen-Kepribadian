# Chatbot Asesmen Psikologi Kepribadian (Streamlit)

🧠 **Chatbot Asesmen Psikologi Kepribadian** adalah aplikasi interaktif berbasis Streamlit untuk melakukan asesmen kepribadian menggunakan kuesioner terstruktur, menampilkan visual infografis, dan menghasilkan laporan lokal (.docx & .csv).

## Fitur Utama
- Kuesioner interaktif (skala Likert 1–5) untuk 7 domain kepribadian.
- Visualisasi Radar Chart dan Donut Chart (Plotly).
- Interpretasi naratif otomatis dan rekomendasi singkat.
- Simpan hasil lokal ke `hasil_asesmen.csv` dan ekspor laporan DOCX.
- Privasi terjaga: semua data disimpan secara lokal.

## Cara Menjalankan
1. Clone repository atau unduh ZIP, lalu ekstrak.
2. Buat virtual environment dan install dependencies:
```bash
pip install -r requirements.txt
```
3. Jalankan:
```bash
streamlit run app.py
```

## Struktur Repository
- `app.py` – Aplikasi Streamlit utama
- `requirements.txt` – Dependensi Python
- `README.md` – Dokumentasi ini
- `hasil_asesmen.csv` – (terbuat setelah menjalankan aplikasi) hasil asesmen

Lisensi: MIT
